# -*- coding: utf-8 -*-

import random
import time
import pyttsx3 
import speech_recognition as sr
engine = pyttsx3.init()      #initialize
r = sr.Recognizer()          #initialize

GREETS=["hello","Hi ","Namaste","satsriakal","Good morning"]
NEXT=["Never mind","I am just a software so dont thank me","I was created for this","U are welcome"]
speak=random.choice(GREETS)

engine.say(speak)
engine.say("I can help you in selecting your course and suggest ways to improve climate" )
engine.say("Please confirm by entering the 5 digit code")
engine.runAndWait()
time.sleep(5)
engine.say('Enter the value')
engine.runAndWait()
Enter=int(input())
if Enter==64582:
    engine.say("Confirmed")
    time.sleep(5)
    engine.say("I am course recommender system")
    engine.say("Starting the process")
    engine.runAndWait()
    engine.say("I can recommend a suitable course for u based upon ur interest and ur marks")
    engine.runAndWait()
    time.sleep(2)
    engine.say("Lets get started")
    engine.say("How much marks did you get in ur 12th class")
    engine.runAndWait()
    with sr.Microphone() as source:
            print("Speak:")                                                                                   
            audio = r.listen(source)   
    marks=r.recognize_google(audio)
    engine.say("You got nice marks.") 
    engine.runAndWait()  
    with sr.Microphone() as source:
            print("Speak:")                                                                                   
            audio = r.listen(source)   
    v1=r.recognize_google(audio)
    NEXT=["Never mind","I am just a software so dont thank me","I was created for this","U are welcome"]
    s1=random.choice(NEXT)
    engine.say(s1)
    engine.runAndWait()
    engine.say("Now which thing you like the most from the list")
    
    time.sleep(3)
    engine.runAndWait()
    print(" Coding","\n","Mechanics","\n","CGI","\n", "Fashion designing","\n","space technology","\n","More courses will be added soon in this system")
    time.sleep(5)
    with sr.Microphone() as source:
        print("Utter:")
        audio=r.listen(source)
    v2=r.recognize_google(audio)
    print(v2)
    if v2=="coding":
        engine.say("Coding has very good scope in future")
        time.sleep(2)
        engine.runAndWait()
        engine.say("u can be a very good programmer as you scored impressive marks in 12th")
        time.sleep(2)
        engine.runAndWait()
        engine.say("You can choose B TECH in CSE")
        time.sleep(1)
        engine.runAndWait()
        engine.say("Ending the process")
        engine.say("bye bye have a nice day")
        time.sleep(10)
        engine.runAndWait()
    elif v2=="mechanics":
        engine.say("ohh mechanics is very good option u can be a mechanical or automobile engineer")
        time.sleep(1.5)
        engine.runAndWait()
        engine.say("Ending the process")
        engine.say("bye bye have a nice day")
        time.sleep(10)
        engine.runAndWait()
    elif v2=="cgi":
        engine.say("ok u r interested in computer graphics")
        engine.say("Lovely professional university has a very good computer animation and graphics programme")
        time.sleep(2)
        engine.runAndWait()
        engine.say("Ending the process")
        engine.say("bye bye have a nice day")
        time.sleep(10)
        engine.runAndWait()
    elif v2=="fashion designing":
        engine.say("People nowadays are more attracted towards fashion")
        time.sleep(1)
        engine.runAndWait()
        engine.say("u can be very good fashion designer like manish malhotra")
        engine.say("U can select fashion designing as ur aim of life")
        engine.runAndWait()
        engine.say("Ending the process")
        engine.say("bye bye have a nice day")
        time.sleep(10)
        engine.runAndWait()
    elif v2=="space technology":
        engine.say("Aeronotics is very fascinating")
        time.sleep(1)
        engine.say("u can  choose aeronotical engineering")
        engine.runAndWait()
        engine.say("Ending the process")
        engine.say("bye bye have a nice day")
        time.sleep(10)
        engine.runAndWait()
    else:
        engine.say("Sorry ERROR:10004")
        time.sleep(1)
        engine.runAndWait()
        engine.say("PLease contact Ashok mittal for more information" )
        time.sleep(0.5)
        engine.runAndWait()
        print("ERROR:10004")
    
    
elif Enter==1234:
    engine.say("Confirmed")
    engine.say("I can provide you valuable information about environment")
    engine.say("Do you want to know how to prevent climate change?")
    time.sleep(2)
    engine.runAndWait()
    engine.say("Press 1 for yes and 2 for no")
    time.sleep(1)
    engine.runAndWait()
    print("Enter the value:")
    variable=int(input())
    if variable==1:
        engine.say("The main problem that cause climate change is POLLUTION")
        time.sleep(1)
        engine.runAndWait()
        engine.say("Air pollution is the main cause of climate change😓😓 ")
        time.sleep(1)
        engine.runAndWait()
        engine.say("Air pollution cause rise in temperature due to which glaciers are melting")
        time.sleep(1.5)
        engine.runAndWait()
        engine.say("Now talking about solutions")
        time.sleep(1)
        engine.runAndWait()
        engine.say("1st solution can be Afforestation")
        time.sleep(1.5)
        engine.say("Because tress reduce air pollution by the replacing carbon dioxide with oxygen")
        engine.runAndWait()
        engine.say("More solutions will be added soon sorry")
        time.sleep(1)
        engine.runAndWait()
    
    
        
     
else:
    engine.say("Wrong code u are unauthorized")
    engine.say("Ending the process")
    engine.say("bye bye have a nice day")
    engine.runAndWait()

    

